<?php $__env->startSection('content'); ?>
<?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
<section class="section section-padding pb-0">
    <div class="container ">

        <div class="row learts-mb-n30 animate_animated wow animate_zoomIn">

            <div class="col-md-6 col-12 align-self-center learts-mb-30">
                <div class="section-title mb-30">
                    <h2><?php echo e(__('About Us')); ?></h2>
                    <p><?php echo e(__('AL-Nezari')); ?></p>
                </div>
                <div class="about-us3">

                    <div class="desc">
                        <p class="">
                            <?php echo e($item->{app()->getLocale().('_intro')}); ?>

                        </p>
                    </div>

                </div>
            </div>

            <div class="col-md-6 imgdd col-12 text-center learts-mb-30">
                <img src='<?php echo e(asset('img/LL.png')); ?>' alt="" style="width: 100%;" class="">

            </div>

        </div>
    </div>

</section>
<!--end about-->
<!-- ======= Featured Section ======= -->
<section id="featured"  class="featured">
    <div class="container mb-4 mt-4">
       
        <div class="row text-center ">
           
            <div class="col-lg-4 mt-4 ">
                <div class="icon-box">
                  
                    <i style="font-size: 40px;" class="fas fa-bullseye"></i>
                    <h3 class="m-4"><?php echo e(__('Target')); ?></h3>
                   
                        <?php echo e($item->{app()->getLocale().('_target')}); ?>

                </div>
            </div>
            <div class="col-lg-4 mt-4 ">
                <div class="icon-box">
                  
                    <i style="font-size: 40px;" class="fa-solid fa-eye"></i>
                    <h3 class="m-4"><?php echo e(__('Vision')); ?></h3>
                    <?php echo e($item->{app()->getLocale().('_vision')}); ?>

                </div>
            </div>
            <div class="col-lg-4 mt-4 ">
                <div class="icon-box">
                  
                    <i style="font-size: 40px;" class="fa-solid fa-circle-check"></i>
                    <h3 class="m-4"><?php echo e(__('Mission')); ?></h3>
                    <?php echo e($item->{app()->getLocale().('_mision')}); ?>

                </div>
            </div>
               
        </div>

    </div>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('page.layouts.master2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MC\Desktop\nezari\backend\nezari\resources\views/page/about.blade.php ENDPATH**/ ?>