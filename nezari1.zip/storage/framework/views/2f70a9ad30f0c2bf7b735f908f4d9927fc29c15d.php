<p <?php echo e($attributes->class(['text-sm text-danger-600 filament-forms-field-wrapper-error-message '])); ?>>
    <?php echo e($slot); ?>

</p>
<?php /**PATH C:\Users\MC\Documents\nezari\vendor\filament\forms\src\/../resources/views/components/field-wrapper/error-message.blade.php ENDPATH**/ ?>