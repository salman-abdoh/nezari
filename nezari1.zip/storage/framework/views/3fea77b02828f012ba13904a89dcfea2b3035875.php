<h2 <?php echo e($attributes->class([
    'text-xl font-bold tracking-tight filament-tables-empty-state-heading',
    'dark:text-white' => config('tables.dark_mode'),
])); ?>>
    <?php echo e($slot); ?>

</h2>
<?php /**PATH C:\Users\MC\Desktop\nezari\backend\nezari\vendor\filament\tables\src\/../resources/views/components/empty-state/heading.blade.php ENDPATH**/ ?>