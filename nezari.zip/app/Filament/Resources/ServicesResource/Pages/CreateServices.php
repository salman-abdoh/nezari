<?php

namespace App\Filament\Resources\ServicesResource\Pages;

use App\Filament\Resources\ServicesResource;
use Filament\Pages\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateServices extends CreateRecord
{
    protected static string $resource = ServicesResource::class;
    protected function mutateFormDataBeforeCreate(array $data): array
    {
        $data['status'] = 1;
        return $data;
    }
}
