<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */
    'en_title'=> "en_title",
    'products'=> "Products",
    'product'=> "Product",
    'about'=>"About Us_",
    'categories'=> "Categories",
    'category'=> "Category",
    'Company'=>"Company",
    'Companies'=>"Companies",
    'service'=> "Service",
    'services'=> "Services",
    'contact'=>"Contant",
    'user'=>"User",
    'users'=>"Users",
    'ArName'=>"Name In arabic",
    'EnName'=>"Name In English",
    'ArDescription'=>"Description In arabic",
    'EnDescription'=>"Description In English",
    'aboutn'=>"Al-Nezari for Import is considered one of the majors medical equipment, cosmetic, pharmaceutical and body care distributors also maintenance of medical and laser devices in the territory and occupies leadership position in the area and aspired to be an agent of the best companies medical and pharmaceutical in the world",





];