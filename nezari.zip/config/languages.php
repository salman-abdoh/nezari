<?php

return [
    'ar' => [
        'display' => 'العــربيــة',
        'flag-icon' => '555460.png',
        'css'=>'ar.css'
        ],
    'en' => [
        'display' => 'English',
        'flag-icon' => 'united-states.png',
        'css'=>'main.css'
    ],
  
   
];