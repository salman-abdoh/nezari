
<?php /**PATH C:\Users\MC\Desktop\nezari\backend\nezari\vendor\filament\filament\src\/../resources/views/components/layouts/app/sidebar/footer.blade.php ENDPATH**/ ?>