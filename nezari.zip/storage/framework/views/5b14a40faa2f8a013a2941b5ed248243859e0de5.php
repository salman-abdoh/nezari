<div
    class="<?php echo \Illuminate\Support\Arr::toCssClasses([
        'filament-notifications-title flex h-6 items-center text-sm font-medium text-gray-900',
        'dark:text-gray-200' => config('notifications.dark_mode'),
    ]) ?>"
>
    <?php echo e($slot); ?>

</div>
<?php /**PATH C:\Users\MC\Desktop\nezari\backend\nezari\vendor\filament\notifications\src\/../resources/views/components/title.blade.php ENDPATH**/ ?>