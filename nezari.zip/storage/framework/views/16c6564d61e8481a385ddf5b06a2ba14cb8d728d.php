<svg class="h-3 w-3 text-gray-400" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20" fill="currentColor" aria-hidden="true">
  <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clip-rule="evenodd"/>
</svg><?php /**PATH C:\Users\MC\Desktop\nezari\backend\nezari\storage\framework\views/0ef9254ffb570564a0093bac9607a12f2b3131f9.blade.php ENDPATH**/ ?>